package utils;

public final class ByteSize {
    public static final int FLOAT = Float.SIZE / 8;
    public static final int INT = Integer.SIZE / 8;
}
