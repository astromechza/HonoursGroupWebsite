package org.uct.cs.simplify;

import org.uct.cs.simplify.gui.preprocessor.PreprocessorWindow;

public class PreprocessorGuiDriver
{
    public static void main(String[] args)
    {
        new PreprocessorWindow();
    }
}
