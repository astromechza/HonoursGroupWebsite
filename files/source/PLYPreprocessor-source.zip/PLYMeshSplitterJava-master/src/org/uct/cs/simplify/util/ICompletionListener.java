package org.uct.cs.simplify.util;

public interface ICompletionListener
{
    void callback(boolean success);
}
