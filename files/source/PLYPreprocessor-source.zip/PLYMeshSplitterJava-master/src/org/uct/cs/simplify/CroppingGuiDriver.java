package org.uct.cs.simplify;

import org.uct.cs.simplify.gui.cropper.CroppingWindow;

public class CroppingGuiDriver
{
    public static void main(String[] args)
    {
        new CroppingWindow();
    }
}
